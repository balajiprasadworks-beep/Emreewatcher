import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { analyzeCalendar, diffCalendarRows, parseEnglishDate } from '../lib/calendar';

const fixture = (name: string) => fs.readFileSync(path.join(process.cwd(), 'tests', 'fixtures', name), 'utf8');

test('parses official-style English dates', () => {
  assert.equal(parseEnglishDate('Sunday, December 21, 2025'), '2025-12-21');
  assert.equal(parseEnglishDate('2027-02-21'), '2027-02-21');
  assert.equal(parseEnglishDate('not a date'), null);
});

test('does not mistake existing 2025-26 rows for the 2026-27 cycle', () => {
  const analysis = analyzeCalendar(fixture('current-2025-26.html'), '2026-27');
  assert.equal(analysis.targetCycleMentioned, false);
  assert.equal(analysis.targetRows.length, 0);
});

test('detects the 2026-27 cycle and parses sittings', () => {
  const analysis = analyzeCalendar(fixture('released-2026-27.html'), '2026-27');
  assert.equal(analysis.targetCycleMentioned, true);
  assert.equal(analysis.targetRows.length, 3);
  assert.equal(analysis.targetRows[0].examinationDate, '2026-12-06');
  assert.equal(analysis.targetRows[1].resultDate, '2027-01-21');
});

test('detects a registration-window update even when the exam date stays constant', () => {
  const old = [{ enrollmentStart: '2026-10-05', enrollmentEnd: '2026-11-25', examinationDate: '2026-12-06', resultDate: '2026-12-10', sourceRowText: '' }];
  const newer = [{ enrollmentStart: '2026-10-15', enrollmentEnd: '2026-11-25', examinationDate: '2026-12-06', resultDate: '2026-12-10', sourceRowText: '' }];
  const diff = diffCalendarRows(old, newer);
  assert.equal(diff.changed.length, 1);
  assert.equal(diff.added.length, 0);
  assert.equal(diff.removed.length, 0);
});
