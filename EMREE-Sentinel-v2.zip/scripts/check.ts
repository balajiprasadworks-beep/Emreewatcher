import { runCheck, pendingDetections } from '../lib/watcher';
import { dispatchDetection } from '../lib/alerts';

async function main() {
  const run = await runCheck();
  const pending = run.skipped ? [] : await pendingDetections(20);
  const results: any[] = [];
  for (const detection of pending) {
    results.push({ id: detection.id, ...(await dispatchDetection(detection)) });
  }
  console.log(JSON.stringify({ run, notifications: results }, null, 2));
  const failed = results.some((item) => !item.allDone);
  if (failed) process.exitCode = 2;
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
