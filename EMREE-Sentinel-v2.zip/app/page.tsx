'use client';

import { useEffect, useState, type ChangeEvent, type FormEvent } from 'react';

type Status = any;

function Login({ error: initialError = '' }: { error?: string }) {
  const [password, setPassword] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState(initialError);

  async function submit(event: FormEvent) {
    event.preventDefault();
    setBusy(true);
    setError('');
    try {
      const response = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ password }),
      });
      const data = await response.json();
      if (!response.ok) setError(data.error || 'Login failed');
      else window.location.reload();
    } catch {
      setError('Unable to reach the dashboard.');
    } finally {
      setBusy(false);
    }
  }

  return (
    <main className="auth">
      <div className="auth-card">
        <div className="mark">E</div>
        <p className="eyebrow">PRIVATE MONITOR</p>
        <h1>EMREE SENTINEL</h1>
        <p className="muted">Official-source calendar monitoring for the 2026–27 EMREE cycle.</p>
        <form onSubmit={submit}>
          <input type="password" placeholder="Dashboard password" value={password} onChange={(e: ChangeEvent<HTMLInputElement>) => setPassword(e.target.value)} autoFocus />
          <button disabled={busy}>{busy ? 'Checking…' : 'Sign in'}</button>
        </form>
        {error && <p className="error">{error}</p>}
      </div>
    </main>
  );
}

function Dashboard({ data, refresh }: { data: Status; refresh: () => void }) {
  const [busy, setBusy] = useState(false);
  const [syncing, setSyncing] = useState(false);
  const [notice, setNotice] = useState('');
  const targetRows = data.targetRows || [];
  const calendar = data.googleCalendar;

  async function runNow() {
    setBusy(true);
    setNotice('');
    try {
      const response = await fetch('/api/check', { cache: 'no-store' });
      const result = await response.json().catch(() => ({}));
      setNotice(result.ok ? 'Check completed.' : result.error || 'Check failed.');
    } finally {
      await refresh();
      setBusy(false);
    }
  }

  async function syncCalendar() {
    setSyncing(true);
    setNotice('');
    try {
      const response = await fetch('/api/google/sync', { method: 'POST' });
      const result = await response.json().catch(() => ({}));
      setNotice(response.ok ? `Calendar synced: ${result.upserted || 0} events, ${result.removed || 0} stale events removed.` : result.error || 'Calendar sync failed.');
    } finally {
      await refresh();
      setSyncing(false);
    }
  }

  async function disconnectCalendar() {
    await fetch('/api/google/disconnect', { method: 'POST' });
    setNotice('Google Calendar disconnected.');
    await refresh();
  }

  const sourceUrl = 'https://nihs.uaeu.ac.ae/en/emirates_medical_residency_entry_exam/calendar.shtml';

  return (
    <main>
      <div className="wrap">
        <header>
          <div>
            <p className="eyebrow">5-MINUTE OFFICIAL-SOURCE MONITOR</p>
            <h1>EMREE SENTINEL</h1>
            <p>2026–27 dates · registration · result dates · change alerts</p>
          </div>
          <div className="header-actions">
            <span className={`pill ${data.healthy ? 'live' : 'warn'}`}>{data.healthy ? '● LIVE' : '● ATTENTION'}</span>
            <button className="ghost" onClick={runNow} disabled={busy}>{busy ? 'Checking…' : 'Check now'}</button>
            <button className="ghost" onClick={async () => { await fetch('/api/auth/logout', { method: 'POST' }); window.location.reload(); }}>Sign out</button>
          </div>
        </header>

        {notice && <div className="notice">{notice}</div>}

        <section className="hero">
          <div>
            <span className="label">TARGET CYCLE</span>
            <strong>{data.targetCycle}</strong>
            <p>{data.targetReleased ? 'Official target-cycle examination rows detected.' : 'Waiting for official target-cycle examination rows.'}</p>
          </div>
          <div className={`state ${data.targetReleased ? 'released' : 'waiting'}`}>
            <span>{data.targetReleased ? 'RELEASE DETECTED' : 'NOT RELEASED'}</span>
          </div>
        </section>

        <section className="grid">
          <div className="card"><span className="label">LAST CHECK</span><strong>{data.lastCheck ? new Date(data.lastCheck).toLocaleString() : '—'}</strong><p>Watcher heartbeat</p></div>
          <div className="card"><span className="label">UNALERTED</span><strong>{data.unalerted}</strong><p>Detections awaiting completion</p></div>
          <div className="card"><span className="label">SITTINGS</span><strong>{targetRows.length}</strong><p>Target-cycle exam dates parsed</p></div>
        </section>

        <section className="card">
          <div className="section-head">
            <div><span className="label">OFFICIAL CALENDAR</span><h2>{data.targetReleased ? `EMREE ${data.targetCycle}` : 'Awaiting 2026–27 release'}</h2></div>
            <a href={sourceUrl} target="_blank" rel="noreferrer">Open NIHS calendar ↗</a>
          </div>
          {targetRows.length ? (
            <div className="table">
              <div className="tr th"><span>Enrollment</span><span>Exam</span><span>Result</span></div>
              {targetRows.map((row: any, index: number) => <div className="tr" key={`${row.examinationDate}-${index}`}><span>{row.enrollmentStart || '—'} → {row.enrollmentEnd || '—'}</span><b>{row.examinationDate}</b><span>{row.resultDate || '—'}</span></div>)}
            </div>
          ) : <div className="empty">The official page is reachable, but no {data.targetCycle} examination rows have been parsed yet.</div>}
        </section>

        <section className="two">
          <div className="card">
            <div className="section-head"><h2>Source health</h2><span className="mini">Live</span></div>
            {data.sourceStates.map((source: any) => (
              <div className="source" key={source.source_key}>
                <div><b>{source.role === 'calendar' ? 'NIHS EMREE Calendar' : 'NIHS EMREE Service'}</b><small>{source.last_checked_at ? new Date(source.last_checked_at).toLocaleString() : 'Never checked'}</small></div>
                <span className={source.consecutive_failures === 0 ? 'ok' : 'bad'}>{source.consecutive_failures === 0 ? 'OK' : `${source.consecutive_failures} failures`}</span>
              </div>
            ))}
          </div>

          <div className="card">
            <div className="section-head"><h2>Google Calendar</h2><span className="mini">Optional</span></div>
            {calendar ? <>
              <p><b>Connected</b></p>
              <p className="muted">Calendar: {calendar.calendar_id}</p>
              {calendar.last_error && <p className="error">{calendar.last_error}</p>}
              <div className="header-actions">
                <button className="ghost" onClick={syncCalendar} disabled={syncing}>{syncing ? 'Syncing…' : 'Sync current dates'}</button>
                <button className="ghost" onClick={disconnectCalendar}>Disconnect</button>
              </div>
            </> : <>
              <p className="muted">Automatically create registration, exam, and result reminders when official dates are released.</p>
              <a className="button" href="/api/google/start">Connect Google Calendar</a>
            </>}
          </div>
        </section>

        <section className="card">
          <div className="section-head"><h2>Recent detections</h2><span className="mini">Audit trail</span></div>
          {data.detections?.length ? data.detections.map((d: any) => (
            <article className="detection" key={d.id}>
              <div><b>{d.title}</b><small>{new Date(d.detected_at).toLocaleString()} · {d.type}</small></div>
              <span className={d.alerted ? 'ok' : 'bad'}>{d.alerted ? 'ALERTED' : 'PENDING'}</span>
            </article>
          )) : <div className="empty">No detections recorded.</div>}
        </section>

        <footer>
          <span>Primary source: NIHS/UAEU · watcher runs independently of browser state</span>
          <a href={sourceUrl} target="_blank" rel="noreferrer">Official EMREE calendar</a>
        </footer>
      </div>
    </main>
  );
}

export default function Home() {
  const [data, setData] = useState<Status | null>(null);
  const [loading, setLoading] = useState(true);

  async function refresh() {
    const response = await fetch('/api/status', { cache: 'no-store' });
    if (response.status === 401) { setData({ unauthenticated: true }); setLoading(false); return; }
    setData(await response.json());
    setLoading(false);
  }

  useEffect(() => {
    refresh().catch(() => setLoading(false));
    const timer = window.setInterval(() => refresh().catch(() => undefined), 30000);
    return () => window.clearInterval(timer);
  }, []);

  if (loading) return <main className="splash"><div className="loader"></div><p>Loading sentinel…</p></main>;
  if (data?.unauthenticated) return <Login />;
  return <Dashboard data={data} refresh={refresh} />;
}
