import './globals.css';

export const metadata = {
  title: 'EMREE Sentinel',
  description: 'Official-source EMREE calendar watcher',
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
