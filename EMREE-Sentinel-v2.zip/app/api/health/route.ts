import { NextResponse } from 'next/server';
import { ensureSchema, sql } from '@/lib/db';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function GET() {
  try {
    await ensureSchema();
    const db = sql();
    await db`SELECT 1 AS ok`;
    return NextResponse.json({ ok: true, service: 'emree-sentinel', timestamp: new Date().toISOString() }, { status: 200 });
  } catch {
    return NextResponse.json({ ok: false, service: 'emree-sentinel' }, { status: 503 });
  }
}
