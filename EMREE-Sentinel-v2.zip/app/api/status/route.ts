import { NextRequest, NextResponse } from 'next/server';
import { requestIsAuthenticated } from '@/lib/auth';
import { publicStatus } from '@/lib/watcher';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
  if (!requestIsAuthenticated(req)) return NextResponse.json({ authenticated: false }, { status: 401 });
  try {
    return NextResponse.json({ authenticated: true, ...(await publicStatus()) });
  } catch (error) {
    return NextResponse.json({ authenticated: true, healthy: false, error: error instanceof Error ? error.message : String(error) }, { status: 500 });
  }
}
