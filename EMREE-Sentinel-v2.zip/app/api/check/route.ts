import { NextRequest, NextResponse } from 'next/server';
import { requestIsAuthenticated } from '@/lib/auth';
import { pendingDetections, runCheck } from '@/lib/watcher';
import { dispatchDetection } from '@/lib/alerts';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';
export const maxDuration = 60;

export async function GET(req: NextRequest) {
  const cronSecret = process.env.CRON_SECRET?.trim();
  const cronAuthorized = Boolean(cronSecret) && req.headers.get('authorization') === `Bearer ${cronSecret}`;
  if (!cronAuthorized && !requestIsAuthenticated(req)) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  try {
    const run = await runCheck();
    const pending = run.skipped ? [] : await pendingDetections(10);
    const notifications = await Promise.all(pending.map(async (detection: any) => ({ id: detection.id, ...(await dispatchDetection(detection)) })));
    return NextResponse.json({ ok: true, run, notifications });
  } catch (error) {
    return NextResponse.json({ ok: false, error: error instanceof Error ? error.message : String(error) }, { status: 500 });
  }
}
