import { NextRequest, NextResponse } from 'next/server';
import { requestIsAuthenticated } from '@/lib/auth';

export const runtime = 'nodejs';

export async function GET(req: NextRequest) {
  return NextResponse.json({ authenticated: requestIsAuthenticated(req) });
}
