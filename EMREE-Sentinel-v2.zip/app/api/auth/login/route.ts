import { NextResponse } from 'next/server';
import { dashboardPasswordMatches, setSessionCookie } from '@/lib/auth';

export const runtime = 'nodejs';

export async function POST(request: Request) {
  try {
    const body = await request.json() as { password?: string };
    if (!body.password || !dashboardPasswordMatches(body.password)) return NextResponse.json({ ok: false, error: 'Invalid password' }, { status: 401 });
    return setSessionCookie(NextResponse.json({ ok: true }));
  } catch (error) {
    return NextResponse.json({ ok: false, error: error instanceof Error ? error.message : String(error) }, { status: 500 });
  }
}
