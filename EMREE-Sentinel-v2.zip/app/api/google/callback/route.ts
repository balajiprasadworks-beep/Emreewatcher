import { NextRequest, NextResponse } from 'next/server';
import { requestIsAuthenticated } from '@/lib/auth';
import { exchangeGoogleCode, saveGoogleConnection } from '@/lib/google';
import { sha256 } from '@/lib/hash';
import { sql } from '@/lib/db';
import { syncCurrentCalendar } from '@/lib/alerts';

export const runtime = 'nodejs';

function sessionToken(req: NextRequest): string | null {
  const cookie = req.headers.get('cookie') || '';
  const found = cookie.split(';').map((x: string) => x.trim()).find((x) => x.startsWith('emree_session='));
  return found ? decodeURIComponent(found.slice('emree_session='.length)) : null;
}

export async function GET(req: NextRequest) {
  if (!requestIsAuthenticated(req)) return NextResponse.redirect(new URL('/?error=auth_required', req.url));
  const code = req.nextUrl.searchParams.get('code');
  const state = req.nextUrl.searchParams.get('state');
  if (!code || !state) return NextResponse.redirect(new URL('/?error=google_callback_missing_parameters', req.url));
  const token = sessionToken(req);
  if (!token) return NextResponse.redirect(new URL('/?error=session_missing', req.url));

  const db = sql();
  const rows = await db`SELECT state_hash FROM oauth_states WHERE state_hash=${sha256(state)} AND expires_at > NOW() AND session_hash=${sha256(token)}`;
  if (!rows[0]) return NextResponse.redirect(new URL('/?error=google_state_invalid', req.url));
  await db`DELETE FROM oauth_states WHERE state_hash=${sha256(state)}`;

  try {
    const tokens = await exchangeGoogleCode(code);
    await saveGoogleConnection(tokens.refresh_token, tokens.access_token);
    let calendarSynced = '0';
    try {
      await syncCurrentCalendar();
      calendarSynced = '1';
    } catch {
      // The OAuth connection is still valid. The dashboard's manual sync action can retry.
    }
    return NextResponse.redirect(new URL(`/?google=connected&calendar_synced=${calendarSynced}`, req.url));
  } catch (error) {
    return NextResponse.redirect(new URL(`/?error=${encodeURIComponent(error instanceof Error ? error.message : String(error))}`, req.url));
  }
}
