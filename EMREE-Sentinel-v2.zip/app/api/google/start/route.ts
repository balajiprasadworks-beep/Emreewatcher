import { NextRequest, NextResponse } from 'next/server';
import { requestIsAuthenticated } from '@/lib/auth';
import { createGoogleAuthorizationUrl } from '@/lib/google';

export const runtime = 'nodejs';

function sessionToken(req: NextRequest): string | null {
  const cookie = req.headers.get('cookie') || '';
  const found = cookie.split(';').map((x: string) => x.trim()).find((x) => x.startsWith('emree_session='));
  return found ? decodeURIComponent(found.slice('emree_session='.length)) : null;
}

export async function GET(req: NextRequest) {
  if (!requestIsAuthenticated(req)) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  const token = sessionToken(req);
  if (!token) return NextResponse.json({ error: 'Session missing' }, { status: 401 });
  try {
    return NextResponse.redirect(await createGoogleAuthorizationUrl(token));
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error ? error.message : String(error) }, { status: 500 });
  }
}
