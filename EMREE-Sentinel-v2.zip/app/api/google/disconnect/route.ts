import { NextRequest, NextResponse } from 'next/server';
import { requestIsAuthenticated } from '@/lib/auth';
import { removeGoogleConnection } from '@/lib/google';

export const runtime = 'nodejs';

export async function POST(req: NextRequest) {
  if (!requestIsAuthenticated(req)) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  await removeGoogleConnection();
  return NextResponse.json({ ok: true });
}
