import { NextRequest, NextResponse } from 'next/server';
import { requestIsAuthenticated } from '@/lib/auth';
import { configuredConnection } from '@/lib/db';

export const runtime = 'nodejs';

export async function GET(req: NextRequest) {
  if (!requestIsAuthenticated(req)) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  const connection = await configuredConnection();
  return NextResponse.json({ connected: Boolean(connection), connection });
}
