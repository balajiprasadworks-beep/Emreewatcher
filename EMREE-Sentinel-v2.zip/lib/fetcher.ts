import { fetchTimeoutMs, maxSourceBytes } from './config';

export type FetchResult = {
  status: number;
  ok: boolean;
  etag?: string;
  lastModified?: string;
  notModified: boolean;
  html?: string;
};

function retryAfterMs(header: string | null): number {
  if (!header) return 0;
  const seconds = Number(header);
  if (Number.isFinite(seconds)) return Math.min(Math.max(seconds * 1000, 0), 15000);
  const date = Date.parse(header);
  if (Number.isFinite(date)) return Math.min(Math.max(date - Date.now(), 0), 15000);
  return 0;
}

async function sleep(ms: number) {
  if (ms > 0) await new Promise((resolve) => setTimeout(resolve, ms));
}

export async function fetchSource(url: string, previous?: { etag?: string | null; lastModified?: string | null }): Promise<FetchResult> {
  const attempts = 3;
  let lastError: unknown;
  for (let attempt = 1; attempt <= attempts; attempt += 1) {
    const headers: Record<string, string> = {
      'User-Agent': process.env.EMREE_USER_AGENT || 'EMREE-Sentinel/2.0 (+official-source-monitor)',
      Accept: 'text/html,application/xhtml+xml;q=0.9,*/*;q=0.8',
      'Accept-Language': 'en-US,en;q=0.8',
      'Cache-Control': 'no-cache',
    };
    if (previous?.etag) headers['If-None-Match'] = previous.etag;
    if (previous?.lastModified) headers['If-Modified-Since'] = previous.lastModified;
    try {
      const response = await fetch(url, {
        method: 'GET',
        headers,
        redirect: 'follow',
        cache: 'no-store',
        signal: AbortSignal.timeout(fetchTimeoutMs()),
      });
      if (response.status === 304) {
        return {
          status: 304,
          ok: true,
          etag: response.headers.get('etag') || previous?.etag || undefined,
          lastModified: response.headers.get('last-modified') || previous?.lastModified || undefined,
          notModified: true,
        };
      }
      if (!response.ok) {
        if (attempt < attempts && (response.status === 429 || response.status >= 500)) {
          await sleep(Math.max(retryAfterMs(response.headers.get('retry-after')), attempt * 1000));
          continue;
        }
        return { status: response.status, ok: false, notModified: false };
      }
      const html = await response.text();
      if (Buffer.byteLength(html, 'utf8') > maxSourceBytes()) throw new Error(`Source response exceeded ${maxSourceBytes()} bytes`);
      return {
        status: response.status,
        ok: true,
        etag: response.headers.get('etag') || undefined,
        lastModified: response.headers.get('last-modified') || undefined,
        notModified: false,
        html,
      };
    } catch (error) {
      lastError = error;
      if (attempt < attempts) {
        await sleep(attempt * 1000);
        continue;
      }
    }
  }
  throw lastError instanceof Error ? lastError : new Error(String(lastError));
}
