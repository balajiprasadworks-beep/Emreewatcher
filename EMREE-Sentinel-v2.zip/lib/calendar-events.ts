import { stableHash } from './hash';

export type CalendarEventInput = {
  id: string;
  cycle: string;
  summary: string;
  description: string;
  date: string;
  sourceUrl: string;
};

export const CALENDAR_EVENT_KINDS = ['REGISTRATION OPENS', 'REGISTRATION DEADLINE', 'EXAM', 'RESULT'] as const;
export type CalendarEventKind = (typeof CALENDAR_EVENT_KINDS)[number];

export function logicalEventId(cycle: string, row: any, kind: CalendarEventKind): string {
  // Google Calendar event IDs must be stable. Exam date is the logical sitting key;
  // changing registration/result dates therefore updates the same event rather than duplicating it.
  return `emree${stableHash({ cycle, examinationDate: row.examinationDate, kind }).slice(0, 40)}`;
}

export function calendarEventDate(row: any, kind: CalendarEventKind): string | null {
  if (kind === 'REGISTRATION OPENS') return row.enrollmentStart || null;
  if (kind === 'REGISTRATION DEADLINE') return row.enrollmentEnd || null;
  if (kind === 'EXAM') return row.examinationDate || null;
  if (kind === 'RESULT') return row.resultDate || null;
  return null;
}

function formatRow(row: any): string {
  return `Enrollment ${row.enrollmentStart || '—'} → ${row.enrollmentEnd || '—'} | Exam ${row.examinationDate} | Result ${row.resultDate || '—'}`;
}

export function calendarEventForRow(cycle: string, row: any, kind: CalendarEventKind, date: string, sourceUrl: string): CalendarEventInput {
  return {
    id: logicalEventId(cycle, row, kind),
    cycle,
    summary: `EMREE ${cycle} — ${kind}`,
    description: `${formatRow(row)}\n\nDetected by EMREE Sentinel.`,
    date,
    sourceUrl,
  };
}

export function calendarEventsForRows(cycle: string, rows: any[], sourceUrl: string): CalendarEventInput[] {
  const events: CalendarEventInput[] = [];
  for (const row of rows) {
    for (const kind of CALENDAR_EVENT_KINDS) {
      const date = calendarEventDate(row, kind);
      if (date) events.push(calendarEventForRow(cycle, row, kind, date, sourceUrl));
    }
  }
  return events;
}

export function calendarPlanForRows(cycle: string, currentRows: any[], previousRows: any[], sourceUrl: string) {
  const upsert = calendarEventsForRows(cycle, currentRows, sourceUrl);
  const remove = new Set<string>();

  // Only remove an old event when its logical sitting disappeared. If the same exam
  // sitting remains but its registration/result date changed, the same event ID is PUT.
  const currentByExam = new Map(currentRows.map((row) => [row.examinationDate, row]));
  for (const row of previousRows) {
    if (currentByExam.has(row.examinationDate)) continue;
    for (const kind of CALENDAR_EVENT_KINDS) {
      if (calendarEventDate(row, kind)) remove.add(logicalEventId(cycle, row, kind));
    }
  }

  return { upsert, remove: [...remove] };
}
