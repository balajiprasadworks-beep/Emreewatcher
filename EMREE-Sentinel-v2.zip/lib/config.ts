export type SourceDefinition = {
  key: string;
  url: string;
  role: 'calendar' | 'context';
};

function env(name: string): string | undefined {
  const value = process.env[name]?.trim();
  return value ? value : undefined;
}

export function requireEnv(name: string): string {
  const value = env(name);
  if (!value) throw new Error(`${name} is not configured`);
  return value;
}

export function targetCycle(): string {
  return env('EMREE_TARGET_CYCLE') || '2026-27';
}

export function sources(): SourceDefinition[] {
  return [
    {
      key: 'emree-calendar',
      url: env('EMREE_CALENDAR_URL') || 'https://nihs.uaeu.ac.ae/en/emirates_medical_residency_entry_exam/calendar.shtml',
      role: 'calendar',
    },
    {
      key: 'emree-service',
      url: env('EMREE_SERVICE_URL') || 'https://nihs.uaeu.ac.ae/en/emirates_medical_residency_entry_exam/',
      role: 'context',
    },
  ];
}

export function fetchTimeoutMs(): number {
  return Math.min(Math.max(Number(env('EMREE_FETCH_TIMEOUT_MS') || 20000), 5000), 60000);
}

export function maxSourceBytes(): number {
  return Math.min(Math.max(Number(env('EMREE_MAX_SOURCE_BYTES') || 2000000), 100000), 10000000);
}

export function outageThreshold(): number {
  return Math.min(Math.max(Number(env('EMREE_OUTAGE_THRESHOLD') || 3), 1), 20);
}

export function targetYearRange(cycle = targetCycle()): { startYear: number; endYear: number } {
  const match = cycle.match(/^(\d{4})\s*[-–—/]\s*(\d{2}|\d{4})$/);
  if (!match) throw new Error(`Invalid EMREE_TARGET_CYCLE: ${cycle}`);
  const startYear = Number(match[1]);
  const suffix = match[2];
  const endYear = suffix.length === 2 ? Math.floor(startYear / 100) * 100 + Number(suffix) : Number(suffix);
  if (endYear !== startYear + 1) throw new Error(`EMREE_TARGET_CYCLE must span consecutive years: ${cycle}`);
  return { startYear, endYear };
}

export function enabledNotificationChannels(): string[] {
  const channels = new Set<string>();
  if (env('RESEND_API_KEY') && env('ALERT_FROM_EMAIL') && env('ALERT_TO_EMAIL')) channels.add('email');
  if (env('TWILIO_ACCOUNT_SID') && env('TWILIO_AUTH_TOKEN') && env('TWILIO_SMS_FROM') && env('TWILIO_SMS_TO')) channels.add('sms');
  if (env('TWILIO_ACCOUNT_SID') && env('TWILIO_AUTH_TOKEN') && env('TWILIO_WHATSAPP_FROM') && env('TWILIO_WHATSAPP_TO') && env('TWILIO_WHATSAPP_CONTENT_SID')) channels.add('whatsapp');
  if (env('GOOGLE_CLIENT_ID') && env('GOOGLE_CLIENT_SECRET') && env('TOKEN_ENCRYPTION_KEY')) channels.add('calendar');
  return [...channels];
}
