import crypto from 'node:crypto';
import type { NextRequest, NextResponse } from 'next/server';

const COOKIE = 'emree_session';
const MAX_AGE = 60 * 60 * 24 * 30;

function secret(): string {
  const value = process.env.SESSION_SECRET?.trim();
  if (!value) throw new Error('SESSION_SECRET is not configured');
  return value;
}

function sign(value: string): string {
  return crypto.createHmac('sha256', secret()).update(value).digest('base64url');
}

function safeEqual(a: string, b: string): boolean {
  const aa = Buffer.from(a);
  const bb = Buffer.from(b);
  return aa.length === bb.length && crypto.timingSafeEqual(aa, bb);
}

function parseCookies(header: string | null): Record<string, string> {
  if (!header) return {};
  return Object.fromEntries(header.split(';').map((part) => part.trim().split('=').map(decodeURIComponent)).filter((pair) => pair.length === 2) as [string, string][]);
}

export function createSessionToken(): string {
  const payload = Buffer.from(JSON.stringify({ exp: Date.now() + MAX_AGE * 1000, v: 1 })).toString('base64url');
  return `${payload}.${sign(payload)}`;
}

export function verifySessionToken(token: string | undefined): boolean {
  if (!token) return false;
  const [payload, signature] = token.split('.');
  if (!payload || !signature || !safeEqual(sign(payload), signature)) return false;
  try {
    const data = JSON.parse(Buffer.from(payload, 'base64url').toString('utf8')) as { exp: number; v: number };
    return data.v === 1 && Number.isFinite(data.exp) && data.exp > Date.now();
  } catch {
    return false;
  }
}

export function requestIsAuthenticated(req: NextRequest | Request): boolean {
  return verifySessionToken(parseCookies(req.headers.get('cookie'))[COOKIE]);
}

export function dashboardPasswordMatches(input: string): boolean {
  const configured = process.env.DASHBOARD_PASSWORD?.trim();
  if (!configured) throw new Error('DASHBOARD_PASSWORD is not configured');
  const a = crypto.createHash('sha256').update(input, 'utf8').digest();
  const b = crypto.createHash('sha256').update(configured, 'utf8').digest();
  return crypto.timingSafeEqual(a, b);
}

export function setSessionCookie(response: NextResponse): NextResponse {
  response.cookies.set({
    name: COOKIE,
    value: createSessionToken(),
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production',
    sameSite: 'lax',
    path: '/',
    maxAge: MAX_AGE,
  });
  return response;
}

export function clearSessionCookie(response: NextResponse): NextResponse {
  response.cookies.set({ name: COOKIE, value: '', httpOnly: true, secure: process.env.NODE_ENV === 'production', sameSite: 'lax', path: '/', maxAge: 0 });
  return response;
}
