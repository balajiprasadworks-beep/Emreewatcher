import { Resend } from 'resend';
import { enabledNotificationChannels, requireEnv } from './config';
import { configuredConnection, sql } from './db';
import { deleteCalendarEvents, syncCurrentGoogleCalendar, upsertCalendarEvents } from './google';
import { calendarPlanForRows } from './calendar-events';

function esc(input: unknown): string {
  return String(input ?? '').replace(/[&<>"']/g, (char) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[char]!));
}

function formatRow(row: any): string {
  return `Enrollment ${row.enrollmentStart || '—'} → ${row.enrollmentEnd || '—'} | Exam ${row.examinationDate} | Result ${row.resultDate || '—'}`;
}

function payloadText(payload: any): string {
  const rows = (payload.currentRows || payload.targetRows || []).map(formatRow).join('\n');
  const diff = payload.diff
    ? `\n\nAdded:\n${payload.diff.added?.map(formatRow).join('\n') || 'None'}\n\nRemoved:\n${payload.diff.removed?.map(formatRow).join('\n') || 'None'}\n\nChanged:\n${payload.diff.changed?.map((x: any) => `Before: ${formatRow(x.previous)}\nAfter: ${formatRow(x.current)}`).join('\n') || 'None'}`
    : '';
  return `${payload.title || 'EMREE update'}\n\n${rows || payload.evidenceText || 'Review the official calendar.'}${diff}\n\nSource: ${payload.sourceUrl}`;
}

export function notificationMessage(detection: any): { subject: string; text: string } {
  const label = detection.type === 'TARGET_CYCLE_RELEASED'
    ? 'OFFICIAL DATES RELEASED'
    : detection.type === 'SOURCE_OUTAGE'
      ? 'OFFICIAL SOURCE UNAVAILABLE'
      : detection.type === 'TARGET_CYCLE_REMOVED'
        ? 'OFFICIAL DATES REMOVED/CHANGED'
        : 'OFFICIAL CALENDAR UPDATED';
  const subject = `🚨 EMREE ${detection.cycle || ''} — ${label}`.replace(/\s+/g, ' ').trim();
  return { subject, text: payloadText(detection.payload) };
}

async function sendEmail(detection: any) {
  const resend = new Resend(requireEnv('RESEND_API_KEY'));
  const { subject, text } = notificationMessage(detection);
  const html = `<div style="font-family:Arial,sans-serif;max-width:720px;margin:auto"><h1>${esc(subject)}</h1><p>${esc(text).replace(/\n/g, '<br>')}</p><hr><p><a href="${esc(detection.source_url)}">Open official source</a></p></div>`;
  const result = await resend.emails.send({ from: requireEnv('ALERT_FROM_EMAIL'), to: requireEnv('ALERT_TO_EMAIL'), subject, text, html });
  if (result.error) throw new Error(result.error.message);
  return result.data?.id || null;
}

async function twilioMessage(params: Record<string, string>) {
  const accountSid = requireEnv('TWILIO_ACCOUNT_SID');
  const token = requireEnv('TWILIO_AUTH_TOKEN');
  const auth = Buffer.from(`${accountSid}:${token}`).toString('base64');
  const response = await fetch(`https://api.twilio.com/2010-04-01/Accounts/${accountSid}/Messages.json`, {
    method: 'POST',
    headers: { Authorization: `Basic ${auth}`, 'content-type': 'application/x-www-form-urlencoded', Accept: 'application/json' },
    body: new URLSearchParams(params),
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.message || `Twilio HTTP ${response.status}`);
  return data.sid as string;
}

async function sendSms(detection: any) {
  const { subject, text } = notificationMessage(detection);
  const body = `${subject}\n${text}`.slice(0, 1450);
  const to = requireEnv('TWILIO_SMS_TO');
  const from = requireEnv('TWILIO_SMS_FROM');
  return twilioMessage({ To: to, From: from, Body: body });
}

async function sendWhatsApp(detection: any) {
  const { subject, text } = notificationMessage(detection);
  return twilioMessage({
    To: requireEnv('TWILIO_WHATSAPP_TO'),
    From: requireEnv('TWILIO_WHATSAPP_FROM'),
    ContentSid: requireEnv('TWILIO_WHATSAPP_CONTENT_SID'),
    ContentVariables: JSON.stringify({ '1': subject, '2': text.slice(0, 900), '3': detection.source_url }),
  });
}

async function sendCalendar(detection: any) {
  const payload = detection.payload || {};
  const currentRows = Array.isArray(payload.currentRows) ? payload.currentRows : (Array.isArray(payload.targetRows) ? payload.targetRows : []);
  const previousRows = Array.isArray(payload.previousRows) ? payload.previousRows : [];
  const plan = calendarPlanForRows(detection.cycle, currentRows, previousRows, detection.source_url);
  if (!plan.upsert.length && !plan.remove.length) throw new Error('No calendar dates were parsed for this detection');
  const ids = await upsertCalendarEvents(plan.upsert);
  await deleteCalendarEvents(plan.remove);
  return [...ids, ...plan.remove.map((x) => `deleted:${x}`)].join(',');
}

export async function syncCurrentCalendar() {
  const db = sql();
  const rows = await db`SELECT semantic_state FROM source_state WHERE source_key='emree-calendar'`;
  const state = rows[0]?.semantic_state as any;
  const targetRows = Array.isArray(state?.targetRows) ? state.targetRows : [];
  const source = process.env.EMREE_CALENDAR_URL || 'https://nihs.uaeu.ac.ae/en/emirates_medical_residency_entry_exam/calendar.shtml';
  const cycle = process.env.EMREE_TARGET_CYCLE || '2026-27';
  return syncCurrentGoogleCalendar(cycle, targetRows, source);
}

async function channelClaim(detectionId: number, channel: string) {
  const db = sql();
  await db`INSERT INTO notification_deliveries(detection_id, channel) VALUES(${detectionId}, ${channel}) ON CONFLICT(detection_id, channel) DO NOTHING`;
  const rows = await db`UPDATE notification_deliveries SET status='sending', attempts=attempts+1, last_attempt_at=NOW(), updated_at=NOW()
    WHERE detection_id=${detectionId} AND channel=${channel}
      AND (
        (status IN ('pending','failed') AND (last_attempt_at IS NULL OR last_attempt_at < NOW() - INTERVAL '30 minutes'))
        OR
        (status='sending' AND last_attempt_at < NOW() - INTERVAL '30 minutes')
      )
    RETURNING id, attempts`;
  return rows[0] || null;
}

async function channelSuccess(detectionId: number, channel: string, providerId: string | null) {
  const db = sql();
  await db`UPDATE notification_deliveries SET status='sent', provider_id=${providerId}, sent_at=NOW(), updated_at=NOW(), last_error=NULL WHERE detection_id=${detectionId} AND channel=${channel}`;
}

async function channelFailure(detectionId: number, channel: string, error: string) {
  const db = sql();
  await db`UPDATE notification_deliveries SET status='failed', last_error=${error.slice(0, 1000)}, updated_at=NOW() WHERE detection_id=${detectionId} AND channel=${channel}`;
}

async function dispatchChannel(detection: any, channel: string) {
  const claim = await channelClaim(Number(detection.id), channel);
  if (!claim) return [channel, 'already-processing-or-sent'] as const;
  try {
    const providerId = channel === 'email'
      ? await sendEmail(detection)
      : channel === 'sms'
        ? await sendSms(detection)
        : channel === 'whatsapp'
          ? await sendWhatsApp(detection)
          : channel === 'calendar'
            ? await sendCalendar(detection)
            : null;
    await channelSuccess(Number(detection.id), channel, providerId);
    return [channel, 'sent'] as const;
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    await channelFailure(Number(detection.id), channel, message);
    return [channel, `failed: ${message}`] as const;
  }
}

export async function dispatchDetection(detection: any) {
  const requested: string[] = Array.isArray(detection.payload?.channelPolicy) ? detection.payload.channelPolicy.map((channel: unknown) => String(channel)) : enabledNotificationChannels();
  const configured = new Set(enabledNotificationChannels());
  let channels = requested.filter((channel: string) => configured.has(channel));
  if (channels.includes('calendar') && !(await configuredConnection())) channels = channels.filter((channel: string) => channel !== 'calendar');

  const resultsEntries = await Promise.all(channels.map((channel) => dispatchChannel(detection, channel)));
  const results = Object.fromEntries(resultsEntries) as Record<string, string>;
  const db = sql();
  const deliveryRows = await db`SELECT channel, status FROM notification_deliveries WHERE detection_id=${Number(detection.id)}`;
  const allDone = deliveryRows.length > 0 && deliveryRows.every((row: any) => row.status === 'sent');
  if (allDone) await db`UPDATE detections SET alerted=true WHERE id=${Number(detection.id)}`;
  return { results, allDone, configuredChannels: channels };
}
