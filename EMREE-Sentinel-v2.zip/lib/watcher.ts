import { acquireLock, createDetection, ensureSchema, releaseLock, sql } from './db';
import { analyzeCalendar, diffCalendarRows } from './calendar';
import { fetchSource } from './fetcher';
import { outageThreshold, sources, targetCycle } from './config';
import { sha256, stableHash } from './hash';

function previousState(row: any): any {
  return row?.semantic_state || null;
}

function releaseState(analysis: any) {
  return {
    targetCycle: analysis.targetCycle,
    targetRows: analysis.targetRows,
  };
}

function releaseDetectionType(previous: any, current: any): { type: string; title: string } | null {
  const wasReleased = Boolean(previous?.targetRows?.length);
  const isReleased = Boolean(current.targetRows.length);
  if (!wasReleased && isReleased) return { type: 'TARGET_CYCLE_RELEASED', title: `EMREE ${current.targetCycle} official dates released` };
  if (wasReleased && !isReleased) return { type: 'TARGET_CYCLE_REMOVED', title: `EMREE ${current.targetCycle} target-cycle entries disappeared from the official calendar` };
  if (wasReleased && isReleased && stableHash(previous) !== stableHash(current)) return { type: 'TARGET_CYCLE_UPDATED', title: `EMREE ${current.targetCycle} official calendar updated` };
  return null;
}

async function checkOneSource(db: ReturnType<typeof sql>, source: ReturnType<typeof sources>[number]) {
  const prevRows = await db`SELECT * FROM source_state WHERE source_key=${source.key}`;
  const prev = prevRows[0] || null;
  const now = new Date().toISOString();
  try {
    const fetched = await fetchSource(source.url, { etag: prev?.etag, lastModified: prev?.last_modified });
    if (fetched.notModified) {
      await db`UPDATE source_state
        SET last_checked_at=${now}, last_success_at=${now}, last_http_status=304,
            consecutive_failures=0, outage_alerted=false, outage_started_at=NULL, updated_at=NOW()
        WHERE source_key=${source.key}`;
      return { ...source, status: 304, changedRaw: false, semanticChanged: false, notModified: true };
    }
    if (!fetched.ok || !fetched.html) throw new Error(`HTTP ${fetched.status}`);

    let semanticState: any;
    let semanticHash: string;
    let createdDetection: any = null;

    if (source.role === 'calendar') {
      const analysis = analyzeCalendar(fetched.html, targetCycle());
      semanticState = releaseState(analysis);
      semanticHash = analysis.semanticHash;
      const previous = previousState(prev);
      const change = releaseDetectionType(previous, semanticState);

      if (change) {
        const diff = diffCalendarRows(previous?.targetRows || [], semanticState.targetRows || []);
        // Include the previous semantic hash in the fingerprint. This means a legitimate
        // A→B→A sequence is still alerted, while repeated A→A polls are deduplicated.
        const fingerprint = stableHash({
          sourceKey: source.key,
          type: change.type,
          cycle: targetCycle(),
          previousSemanticHash: prev?.semantic_hash || null,
          semanticHash,
        });
        createdDetection = await createDetection({
          fingerprint,
          type: change.type,
          cycle: targetCycle(),
          source_key: source.key,
          source_url: source.url,
          title: change.title,
          payload: {
            title: change.title,
            sourceUrl: source.url,
            targetCycle: targetCycle(),
            currentRows: semanticState.targetRows,
            previousRows: previous?.targetRows || [],
            diff,
            evidenceText: analysis.evidenceText,
          },
        });
      }
    } else {
      // Context source is health/fallback evidence only. It must never generate an EMREE
      // release alert because its HTML can change for unrelated reasons.
      semanticState = { reachable: true };
      semanticHash = stableHash(semanticState);
    }

    const rawHash = sha256(fetched.html);
    await db`INSERT INTO source_state(
        source_key,url,role,etag,last_modified,raw_hash,semantic_hash,semantic_state,
        last_checked_at,last_success_at,last_http_status,consecutive_failures,outage_alerted,outage_started_at
      ) VALUES(
        ${source.key},${source.url},${source.role},${fetched.etag || null},${fetched.lastModified || null},
        ${rawHash},${semanticHash},${JSON.stringify(semanticState)}::jsonb,${now},${now},${fetched.status},0,false,NULL
      )
      ON CONFLICT(source_key) DO UPDATE SET
        url=EXCLUDED.url,role=EXCLUDED.role,etag=EXCLUDED.etag,last_modified=EXCLUDED.last_modified,
        raw_hash=EXCLUDED.raw_hash,semantic_hash=EXCLUDED.semantic_hash,semantic_state=EXCLUDED.semantic_state,
        last_checked_at=EXCLUDED.last_checked_at,last_success_at=EXCLUDED.last_success_at,last_http_status=EXCLUDED.last_http_status,
        consecutive_failures=0,outage_alerted=false,outage_started_at=NULL,updated_at=NOW()`;

    return {
      ...source,
      status: fetched.status,
      changedRaw: prev?.raw_hash !== rawHash,
      semanticChanged: prev?.semantic_hash !== semanticHash,
      createdDetection,
    };
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    const previousFailures = Number(prev?.consecutive_failures || 0);
    const failures = previousFailures + 1;
    const outageAlreadyAlerted = Boolean(prev?.outage_alerted);
    const outageStartedAt = prev?.outage_started_at || now;
    const httpMatch = message.match(/HTTP (\d+)/);

    await db`INSERT INTO source_state(
        source_key,url,role,consecutive_failures,last_checked_at,last_http_status,outage_alerted,outage_started_at
      ) VALUES(
        ${source.key},${source.url},${source.role},${failures},${now},${Number(httpMatch?.[1] || 0)},${outageAlreadyAlerted},${outageStartedAt}
      )
      ON CONFLICT(source_key) DO UPDATE SET
        consecutive_failures=${failures},last_checked_at=${now},last_http_status=EXCLUDED.last_http_status,
        outage_started_at=COALESCE(source_state.outage_started_at, EXCLUDED.outage_started_at),updated_at=NOW()`;

    let createdDetection: any = null;
    if (failures >= outageThreshold() && !outageAlreadyAlerted) {
      const fingerprint = sha256(`outage:${source.key}:${outageStartedAt}`);
      createdDetection = await createDetection({
        fingerprint,
        type: 'SOURCE_OUTAGE',
        cycle: targetCycle(),
        source_key: source.key,
        source_url: source.url,
        title: `EMREE official source unavailable: ${source.key}`,
        payload: {
          title: `EMREE official source unavailable: ${source.key}`,
          sourceUrl: source.url,
          targetCycle: targetCycle(),
          error: message,
          consecutiveFailures: failures,
          channelPolicy: ['email', 'sms', 'whatsapp'],
        },
      });
      await db`UPDATE source_state SET outage_alerted=true WHERE source_key=${source.key}`;
    }

    return { ...source, ok: false, error: message, consecutiveFailures: failures, createdDetection };
  }
}

export async function runCheck(): Promise<{ skipped: boolean; createdDetections: any[]; sourceResults: any[] }> {
  await ensureSchema();
  if (!(await acquireLock())) return { skipped: true, createdDetections: [], sourceResults: [] };
  const db = sql();
  try {
    const results = await Promise.all(sources().map((source) => checkOneSource(db, source)));
    const createdDetections = results.flatMap((result: any) => result.createdDetection ? [result.createdDetection] : []);
    return { skipped: false, createdDetections, sourceResults: results };
  } finally {
    await releaseLock();
  }
}

export async function pendingDetections(limit = 10) {
  await ensureSchema();
  const db = sql();
  return db`SELECT * FROM detections WHERE alerted=false ORDER BY id ASC LIMIT ${limit}`;
}

export async function publicStatus() {
  await ensureSchema();
  const db = sql();
  const [lastCheck, sourcesState, detections, detectionCount, connection, deliveries] = await Promise.all([
    db`SELECT last_checked_at AS checked_at FROM source_state ORDER BY last_checked_at DESC NULLS LAST LIMIT 1`,
    db`SELECT source_key,url,role,last_checked_at,last_success_at,last_http_status,consecutive_failures,semantic_state FROM source_state ORDER BY source_key`,
    db`SELECT id,detected_at,type,cycle,title,source_url,alerted FROM detections ORDER BY id DESC LIMIT 20`,
    db`SELECT COUNT(*)::int AS count FROM detections WHERE alerted=false`,
    db`SELECT id,calendar_id,last_error,connected_at,updated_at FROM google_calendar_connection WHERE id=1`,
    db`SELECT d.id, d.type, d.title, n.channel, n.status, n.attempts, n.last_error, n.sent_at FROM detections d JOIN notification_deliveries n ON n.detection_id=d.id ORDER BY n.updated_at DESC LIMIT 40`,
  ]);
  const calendarState = sourcesState.find((row: any) => row.role === 'calendar');
  const currentRows = (calendarState?.semantic_state as any)?.targetRows || [];
  return {
    healthy: Boolean(calendarState) && Number(calendarState?.consecutive_failures || 0) === 0,
    lastCheck: lastCheck[0]?.checked_at || null,
    targetCycle: targetCycle(),
    targetReleased: currentRows.length > 0,
    targetRows: currentRows,
    sourceStates: sourcesState,
    detections,
    unalerted: Number(detectionCount[0]?.count || 0),
    googleCalendar: connection[0] || null,
    deliveries,
  };
}
