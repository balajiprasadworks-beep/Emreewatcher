import { neon } from '@neondatabase/serverless';

export function sql() {
  const url = process.env.DATABASE_URL;
  if (!url) throw new Error('DATABASE_URL is not configured');
  return neon(url);
}

export async function ensureSchema() {
  const db = sql();
  await db`CREATE TABLE IF NOT EXISTS source_state (
    source_key TEXT PRIMARY KEY,
    url TEXT NOT NULL,
    role TEXT NOT NULL,
    etag TEXT,
    last_modified TEXT,
    raw_hash TEXT,
    semantic_hash TEXT,
    semantic_state JSONB,
    last_checked_at TIMESTAMPTZ,
    last_success_at TIMESTAMPTZ,
    last_http_status INT,
    consecutive_failures INT NOT NULL DEFAULT 0,
    outage_alerted BOOLEAN NOT NULL DEFAULT FALSE,
    outage_started_at TIMESTAMPTZ,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
  )`;
  await db`ALTER TABLE source_state ADD COLUMN IF NOT EXISTS outage_started_at TIMESTAMPTZ`;
  await db`CREATE TABLE IF NOT EXISTS detections (
    id BIGSERIAL PRIMARY KEY,
    fingerprint TEXT NOT NULL UNIQUE,
    detected_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    type TEXT NOT NULL,
    cycle TEXT,
    source_key TEXT NOT NULL,
    source_url TEXT NOT NULL,
    title TEXT NOT NULL,
    payload JSONB NOT NULL,
    alerted BOOLEAN NOT NULL DEFAULT FALSE
  )`;
  await db`CREATE TABLE IF NOT EXISTS notification_deliveries (
    id BIGSERIAL PRIMARY KEY,
    detection_id BIGINT NOT NULL REFERENCES detections(id) ON DELETE CASCADE,
    channel TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'pending',
    attempts INT NOT NULL DEFAULT 0,
    provider_id TEXT,
    last_error TEXT,
    last_attempt_at TIMESTAMPTZ,
    sent_at TIMESTAMPTZ,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE(detection_id, channel)
  )`;
  await db`CREATE INDEX IF NOT EXISTS detections_unalerted_idx ON detections(alerted, id)`;
  await db`CREATE INDEX IF NOT EXISTS notification_delivery_detection_idx ON notification_deliveries(detection_id, status)`;
  await db`CREATE TABLE IF NOT EXISTS watcher_lock (
    id INT PRIMARY KEY,
    locked_until TIMESTAMPTZ NOT NULL,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
  )`;
  await db`INSERT INTO watcher_lock(id, locked_until) VALUES(1, NOW() - INTERVAL '1 minute') ON CONFLICT (id) DO NOTHING`;
  await db`CREATE TABLE IF NOT EXISTS oauth_states (
    state_hash TEXT PRIMARY KEY,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    expires_at TIMESTAMPTZ NOT NULL,
    session_hash TEXT NOT NULL
  )`;
  await db`CREATE TABLE IF NOT EXISTS google_calendar_connection (
    id INT PRIMARY KEY,
    refresh_token_enc TEXT NOT NULL,
    calendar_id TEXT NOT NULL DEFAULT 'primary',
    last_error TEXT,
    connected_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
  )`;
  // Upgrade path from the earlier watcher schema. Extra legacy columns are harmless and are intentionally left in place.
  await db`ALTER TABLE google_calendar_connection ADD COLUMN IF NOT EXISTS calendar_id TEXT NOT NULL DEFAULT 'primary'`;
}

export async function acquireLock(ttlMinutes = 10): Promise<boolean> {
  const db = sql();
  const rows = await db`UPDATE watcher_lock
    SET locked_until = NOW() + make_interval(mins => ${ttlMinutes}), updated_at = NOW()
    WHERE id = 1 AND locked_until < NOW()
    RETURNING id`;
  return rows.length === 1;
}

export async function releaseLock() {
  const db = sql();
  await db`UPDATE watcher_lock SET locked_until = NOW(), updated_at = NOW() WHERE id = 1`;
}

export type DetectionRow = {
  id: number;
  fingerprint: string;
  detected_at: string;
  type: string;
  cycle: string | null;
  source_key: string;
  source_url: string;
  title: string;
  payload: any;
  alerted: boolean;
};

export async function createDetection(input: Omit<DetectionRow, 'id' | 'detected_at' | 'alerted'>): Promise<DetectionRow | null> {
  const db = sql();
  const rows = await db`INSERT INTO detections(fingerprint, type, cycle, source_key, source_url, title, payload)
    VALUES(${input.fingerprint}, ${input.type}, ${input.cycle}, ${input.source_key}, ${input.source_url}, ${input.title}, ${JSON.stringify(input.payload)}::jsonb)
    ON CONFLICT(fingerprint) DO NOTHING
    RETURNING *`;
  return (rows[0] as DetectionRow | undefined) || null;
}

export async function configuredConnection() {
  const db = sql();
  const rows = await db`SELECT id, calendar_id, last_error, connected_at, updated_at FROM google_calendar_connection WHERE id = 1`;
  return rows[0] || null;
}
