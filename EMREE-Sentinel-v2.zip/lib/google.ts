import { sql } from './db';
import { decryptSecret, encryptSecret, randomToken, sha256 } from './hash';
import { requireEnv } from './config';
import { calendarEventsForRows, type CalendarEventInput } from './calendar-events';

const CALENDAR_SCOPE = 'https://www.googleapis.com/auth/calendar.events';

function googleClient() {
  return {
    clientId: requireEnv('GOOGLE_CLIENT_ID'),
    clientSecret: requireEnv('GOOGLE_CLIENT_SECRET'),
    redirectUri: requireEnv('GOOGLE_OAUTH_REDIRECT_URI'),
  };
}

async function googleFetch(url: string, init: RequestInit = {}) {
  const response = await fetch(url, {
    ...init,
    headers: {
      Accept: 'application/json',
      ...(init.headers || {}),
    },
  });
  if (!response.ok) {
    const data = await response.json().catch(() => ({}));
    throw new Error(data.error?.message || data.error_description || `Google API HTTP ${response.status}`);
  }
  return response;
}

export async function createGoogleAuthorizationUrl(sessionToken: string): Promise<string> {
  const { clientId, redirectUri } = googleClient();
  const state = randomToken(32);
  const db = sql();
  await db`DELETE FROM oauth_states WHERE expires_at < NOW()`;
  await db`INSERT INTO oauth_states(state_hash, expires_at, session_hash) VALUES(${sha256(state)}, NOW() + INTERVAL '10 minutes', ${sha256(sessionToken)})`;
  const params = new URLSearchParams({
    client_id: clientId,
    redirect_uri: redirectUri,
    response_type: 'code',
    scope: CALENDAR_SCOPE,
    access_type: 'offline',
    prompt: 'consent',
    include_granted_scopes: 'true',
    state,
  });
  return `https://accounts.google.com/o/oauth2/v2/auth?${params.toString()}`;
}

export async function exchangeGoogleCode(code: string) {
  const { clientId, clientSecret, redirectUri } = googleClient();
  const body = new URLSearchParams({ client_id: clientId, client_secret: clientSecret, code, grant_type: 'authorization_code', redirect_uri: redirectUri });
  const response = await fetch('https://oauth2.googleapis.com/token', {
    method: 'POST',
    headers: { 'content-type': 'application/x-www-form-urlencoded', Accept: 'application/json' },
    body,
  });
  const data = await response.json() as any;
  if (!response.ok || !data.refresh_token) throw new Error(`Google token exchange failed: ${data.error_description || data.error || 'refresh token not returned'}`);
  return data as { access_token: string; refresh_token: string; expires_in: number; scope: string; token_type: string };
}

export async function saveGoogleConnection(refreshToken: string, _accessToken: string, calendarId = process.env.GOOGLE_CALENDAR_ID || 'primary') {
  const db = sql();
  await db`INSERT INTO google_calendar_connection(id, refresh_token_enc, calendar_id, last_error)
    VALUES(1, ${encryptSecret(refreshToken, requireEnv('TOKEN_ENCRYPTION_KEY'))}, ${calendarId}, NULL)
    ON CONFLICT(id) DO UPDATE SET refresh_token_enc = EXCLUDED.refresh_token_enc, calendar_id = EXCLUDED.calendar_id, last_error = NULL, updated_at = NOW()`;
}

export async function getGoogleAccessToken() {
  const db = sql();
  const rows = await db`SELECT refresh_token_enc FROM google_calendar_connection WHERE id = 1`;
  if (!rows[0]) throw new Error('Google Calendar is not connected');
  const { clientId, clientSecret } = googleClient();
  const refreshToken = decryptSecret(rows[0].refresh_token_enc as string, requireEnv('TOKEN_ENCRYPTION_KEY'));
  const body = new URLSearchParams({ client_id: clientId, client_secret: clientSecret, refresh_token: refreshToken, grant_type: 'refresh_token' });
  const response = await fetch('https://oauth2.googleapis.com/token', {
    method: 'POST',
    headers: { 'content-type': 'application/x-www-form-urlencoded', Accept: 'application/json' },
    body,
  });
  const data = await response.json() as any;
  if (!response.ok || !data.access_token) {
    await db`UPDATE google_calendar_connection SET last_error = ${data.error_description || data.error || 'Google token refresh failed'}, updated_at = NOW() WHERE id = 1`;
    throw new Error(`Google token refresh failed: ${data.error_description || data.error || 'unknown error'}`);
  }
  await db`UPDATE google_calendar_connection SET last_error = NULL, updated_at = NOW() WHERE id = 1`;
  return data.access_token as string;
}

async function calendarContext() {
  const db = sql();
  const rows = await db`SELECT calendar_id FROM google_calendar_connection WHERE id = 1`;
  if (!rows[0]) throw new Error('Google Calendar is not connected');
  return {
    calendarId: rows[0]?.calendar_id || process.env.GOOGLE_CALENDAR_ID || 'primary',
    accessToken: await getGoogleAccessToken(),
  };
}

export async function upsertCalendarEvents(events: CalendarEventInput[]) {
  if (!events.length) return [];
  const { accessToken, calendarId } = await calendarContext();
  const base = `https://www.googleapis.com/calendar/v3/calendars/${encodeURIComponent(calendarId)}/events`;
  const created: string[] = [];

  for (const event of events) {
    const nextDay = new Date(`${event.date}T00:00:00Z`);
    nextDay.setUTCDate(nextDay.getUTCDate() + 1);
    const endDate = nextDay.toISOString().slice(0, 10);
    const resource = {
      id: event.id,
      summary: event.summary,
      description: `${event.description}\n\nOfficial source: ${event.sourceUrl}`,
      start: { date: event.date },
      end: { date: endDate },
      reminders: { useDefault: false, overrides: [{ method: 'popup', minutes: 10080 }, { method: 'popup', minutes: 1440 }, { method: 'popup', minutes: 120 }] },
      extendedProperties: { private: { emreeSentinel: '1', emreeCycle: event.cycle, emreeEventId: event.id } },
    };

    const insert = await fetch(base, {
      method: 'POST',
      headers: { Authorization: `Bearer ${accessToken}`, 'content-type': 'application/json', Accept: 'application/json' },
      body: JSON.stringify(resource),
    });
    if (insert.status === 409) {
      const update = await googleFetch(`${base}/${encodeURIComponent(event.id)}`, {
        method: 'PUT',
        headers: { Authorization: `Bearer ${accessToken}`, 'content-type': 'application/json' },
        body: JSON.stringify(resource),
      });
      const data = await update.json() as { id?: string };
      created.push(data.id || event.id);
      continue;
    }
    if (!insert.ok) {
      const data = await insert.json().catch(() => ({}));
      throw new Error(`Google Calendar insert failed: ${data.error?.message || insert.status}`);
    }
    const data = await insert.json().catch(() => ({})) as { id?: string };
    created.push(data.id || event.id);
  }
  return created;
}

export async function deleteCalendarEvents(eventIds: string[]) {
  if (!eventIds.length) return [];
  const { accessToken, calendarId } = await calendarContext();
  const base = `https://www.googleapis.com/calendar/v3/calendars/${encodeURIComponent(calendarId)}/events`;
  const deleted: string[] = [];
  for (const id of eventIds) {
    const response = await fetch(`${base}/${encodeURIComponent(id)}`, { method: 'DELETE', headers: { Authorization: `Bearer ${accessToken}` } });
    if (!response.ok && response.status !== 404) {
      const data = await response.json().catch(() => ({}));
      throw new Error(`Google Calendar delete failed: ${data.error?.message || response.status}`);
    }
    deleted.push(id);
  }
  return deleted;
}

async function listManagedEventIds(cycle: string) {
  const { accessToken, calendarId } = await calendarContext();
  const base = `https://www.googleapis.com/calendar/v3/calendars/${encodeURIComponent(calendarId)}/events`;
  const ids: string[] = [];
  let pageToken: string | undefined;
  do {
    const params = new URLSearchParams({ maxResults: '2500', privateExtendedProperty: 'emreeSentinel=1', showDeleted: 'false' });
    if (pageToken) params.set('pageToken', pageToken);
    const response = await googleFetch(`${base}?${params.toString()}`, { headers: { Authorization: `Bearer ${accessToken}` } });
    const data = await response.json() as any;
    for (const item of data.items || []) {
      if (item.extendedProperties?.private?.emreeCycle === cycle && item.id) ids.push(item.id);
    }
    pageToken = data.nextPageToken || undefined;
  } while (pageToken);
  return ids;
}

export async function syncCurrentGoogleCalendar(cycle: string, rows: any[], sourceUrl: string) {
  const desired = calendarEventsForRows(cycle, rows, sourceUrl);
  await upsertCalendarEvents(desired);
  const desiredIds = new Set(desired.map((event) => event.id));
  const existingIds = await listManagedEventIds(cycle);
  const staleIds = existingIds.filter((id) => !desiredIds.has(id));
  await deleteCalendarEvents(staleIds);
  return { upserted: desired.length, removed: staleIds.length };
}

export async function removeGoogleConnection() {
  const db = sql();
  await db`DELETE FROM google_calendar_connection WHERE id = 1`;
}
