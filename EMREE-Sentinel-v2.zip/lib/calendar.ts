import * as cheerio from 'cheerio';
import { stableHash } from './hash';
import { targetCycle, targetYearRange } from './config';

export type CalendarRow = {
  enrollmentStart: string | null;
  enrollmentEnd: string | null;
  examinationDate: string;
  resultDate: string | null;
  sourceRowText: string;
};

export type CalendarAnalysis = {
  title: string;
  calendarTableFound: boolean;
  parseableRowCount: number;
  targetCycle: string;
  targetCycleMentioned: boolean;
  targetRows: CalendarRow[];
  semanticHash: string;
  evidenceText: string;
};

const MONTHS: Record<string, number> = {
  january: 1,
  february: 2,
  march: 3,
  april: 4,
  may: 5,
  june: 6,
  july: 7,
  august: 8,
  september: 9,
  october: 10,
  november: 11,
  december: 12,
};

const WEEKDAYS = '(?:Monday|Tuesday|Wednesday|Thursday|Friday|Saturday|Sunday)?';
const MONTH_PATTERN = '(January|February|March|April|May|June|July|August|September|October|November|December)';

export function normalizeText(input: string): string {
  return input.replace(/\u00a0/g, ' ').replace(/\s+/g, ' ').trim();
}

function validDate(year: number, month: number, day: number): boolean {
  const d = new Date(Date.UTC(year, month - 1, day));
  return d.getUTCFullYear() === year && d.getUTCMonth() === month - 1 && d.getUTCDate() === day;
}

function isoDate(year: number, month: number, day: number): string | null {
  if (!validDate(year, month, day)) return null;
  return `${year.toString().padStart(4, '0')}-${month.toString().padStart(2, '0')}-${day.toString().padStart(2, '0')}`;
}

export function parseEnglishDate(input: string): string | null {
  const text = normalizeText(input).replace(/,/g, '');

  // Official NIHS format: Sunday December 21 2025.
  let match = text.match(new RegExp(`^${WEEKDAYS}\\s*${MONTH_PATTERN}\\s+(\\d{1,2})(?:st|nd|rd|th)?\\s+(\\d{4})$`, 'i'));
  if (match) return isoDate(Number(match[3]), MONTHS[match[1].toLowerCase()], Number(match[2]));

  // Also tolerate the common day-first English format if NIHS redesigns the table.
  match = text.match(new RegExp(`^${WEEKDAYS}\\s*(\\d{1,2})(?:st|nd|rd|th)?\\s+${MONTH_PATTERN}\\s+(\\d{4})$`, 'i'));
  if (match) return isoDate(Number(match[3]), MONTHS[match[2].toLowerCase()], Number(match[1]));

  // ISO / numeric fallback.
  match = text.match(/^(\d{4})[-\/]([01]?\d)[-\/]([0-3]?\d)$/);
  if (match) return isoDate(Number(match[1]), Number(match[2]), Number(match[3]));

  return null;
}

function cycleMentioned(text: string, cycle: string): boolean {
  const { startYear, endYear } = targetYearRange(cycle);
  const shortEnd = String(endYear).slice(-2);
  const re = new RegExp(`${startYear}\\s*(?:-|–|—|/|to)\\s*(?:${shortEnd}|${endYear})`, 'i');
  return re.test(text);
}

function inTargetWindow(date: string, cycle: string): boolean {
  const { startYear, endYear } = targetYearRange(cycle);
  return date >= `${startYear}-12-01` && date <= `${endYear}-03-31`;
}

function parseRows(html: string): { rows: CalendarRow[]; tableFound: boolean; parseableRowCount: number } {
  const $ = cheerio.load(html);
  const output: CalendarRow[] = [];
  let tableFound = false;
  let parseableRowCount = 0;

  $('table').each((_tableIndex: number, table: any) => {
    const rows = $(table).find('tr').toArray().map((row: any) =>
      $(row).find('th,td').toArray().map((cell: any) => normalizeText($(cell).text())),
    );

    const headerIndex = rows.findIndex((cells: string[]) => {
      const header = cells.join(' | ').toLowerCase();
      return header.includes('enrollment start') && (header.includes('enrollment ends') || header.includes('enrollment end')) && header.includes('examination date');
    });
    if (headerIndex < 0) return;
    tableFound = true;

    for (const cells of rows.slice(headerIndex + 1)) {
      if (cells.length < 4 || cells.slice(0, 4).every((value: string) => !value)) continue;
      const examinationDate = parseEnglishDate(cells[2]);
      if (!examinationDate) continue;
      parseableRowCount += 1;
      output.push({
        enrollmentStart: parseEnglishDate(cells[0]),
        enrollmentEnd: parseEnglishDate(cells[1]),
        examinationDate,
        resultDate: parseEnglishDate(cells[3]),
        sourceRowText: cells.slice(0, 4).join(' | '),
      });
    }
  });

  const unique = new Map<string, CalendarRow>();
  for (const row of output) {
    // Exam date is the logical sitting key; duplicate source rows are collapsed.
    unique.set(row.examinationDate, row);
  }
  return {
    rows: [...unique.values()].sort((a, b) => a.examinationDate.localeCompare(b.examinationDate)),
    tableFound,
    parseableRowCount,
  };
}

export function validateOfficialCalendarHtml(html: string): void {
  const $ = cheerio.load(html);
  const text = normalizeText($.text()).toLowerCase();
  const markers = [
    'emirates medical residency entrance examination',
    'enrollment start',
    'examination date',
    'national institute for health specialties',
  ];
  const matched = markers.filter((marker) => text.includes(marker));
  const hasIdentity = text.includes('emirates medical residency entrance examination') || text.includes('emree');
  if (matched.length < 2 || !hasIdentity || !text.includes('examination date')) {
    throw new Error('Official calendar validation failed: expected NIHS/EMREE calendar markers were not found');
  }
}

export function analyzeCalendar(html: string, cycle = targetCycle()): CalendarAnalysis {
  validateOfficialCalendarHtml(html);
  const $ = cheerio.load(html);
  const bodyText = normalizeText($.text());
  const title = normalizeText($('title').first().text()) || 'Emirates Medical Residency Entrance Examination Service';
  const parsed = parseRows(html);
  if (!parsed.tableFound || parsed.parseableRowCount === 0) {
    throw new Error('Official calendar structure changed: no parseable EMREE examination rows found');
  }
  const rows = parsed.rows.filter((row) => inTargetWindow(row.examinationDate, cycle));
  const mentioned = cycleMentioned(bodyText, cycle);
  const state = { targetCycle: cycle, targetRows: rows };
  return {
    title,
    calendarTableFound: parsed.tableFound,
    parseableRowCount: parsed.parseableRowCount,
    targetCycle: cycle,
    targetCycleMentioned: mentioned,
    targetRows: rows,
    semanticHash: stableHash(state),
    evidenceText: rows.map((row: any) => row.sourceRowText).join('\n') || (mentioned ? `The official page mentions ${cycle} but no calendar rows were parsed.` : 'No target-cycle entries detected.'),
  };
}

export function diffCalendarRows(previous: CalendarRow[] = [], current: CalendarRow[] = []) {
  const byExamDate = (rows: CalendarRow[]) => new Map(rows.map((row: any) => [row.examinationDate, row]));
  const prev = byExamDate(previous);
  const next = byExamDate(current);
  const added: CalendarRow[] = [];
  const removed: CalendarRow[] = [];
  const changed: Array<{ previous: CalendarRow; current: CalendarRow }> = [];
  for (const [date, row] of next) {
    const before = prev.get(date);
    if (!before) added.push(row);
    else if (stableHash(before) !== stableHash(row)) changed.push({ previous: before, current: row });
  }
  for (const [date, row] of prev) if (!next.has(date)) removed.push(row);
  return { added, removed, changed };
}
