# EMREE Sentinel

Reliable official-source monitoring for the **Emirates Medical Residency Entrance Examination (EMREE)** calendar, focused on the **2026–27 cycle**.

## What it detects

The sentinel does not alert on arbitrary webpage edits. It validates the official NIHS EMREE page, parses the calendar table, and compares only the meaningful calendar fields:

- enrollment start
- enrollment end
- examination date
- result date

A release alert is generated only when at least one examination row for the configured cycle appears. A registration-window change is still treated as a semantic calendar update. A temporary source failure is tracked separately and can generate an outage alert.

The configured cycle `2026-27` means examination dates from **December 2026 through March 2027**. NIHS currently states that EMREE examinations are held from December to March annually.

## Architecture

```text
NIHS official EMREE calendar
            │
            ▼
GitHub Actions every 5 minutes
            │
            ▼
Vercel /api/check (CRON_SECRET)
            │
            ├── fetch + retry + timeout
            ├── official-page validation
            ├── semantic table parsing
            ├── PostgreSQL state / lock / audit trail
            └── per-channel idempotent delivery
                    │
          ┌─────────┼─────────┬───────────┐
          ▼         ▼         ▼           ▼
        Email      SMS     WhatsApp   Google Calendar
```

The monitoring worker deliberately **does not depend on Vercel Cron**. The GitHub Actions schedule is the heartbeat. The Vercel deployment is the stateless HTTP worker/dashboard. This also avoids a Vercel Hobby once-daily cron limitation.

## Current official source

Primary source:

`https://nihs.uaeu.ac.ae/en/emirates_medical_residency_entry_exam/calendar.shtml`

NIHS is the source of truth. Secondary websites may be monitored separately in a future version, but they do not override the official calendar.

## Deploy

### 1. GitHub

Put this project at the **repository root**. The original project stored the Next.js app inside a ZIP; Sentinel is flattened so Vercel deploys the actual application directly.

Recommended branch flow:

```text
main
  └── sentinel-v2
```

### 2. Neon/Postgres

Create a Neon Postgres database and set:

```text
DATABASE_URL=...
```

The application creates/updates its own schema on first use.

### 3. Vercel

Import the GitHub repository as a Next.js project. No Vercel Cron is required.

Set at least:

```text
DATABASE_URL
DASHBOARD_PASSWORD
SESSION_SECRET
CRON_SECRET
RESEND_API_KEY
ALERT_FROM_EMAIL
ALERT_TO_EMAIL
```

For Google Calendar also set:

```text
GOOGLE_CLIENT_ID
GOOGLE_CLIENT_SECRET
GOOGLE_OAUTH_REDIRECT_URI
GOOGLE_CALENDAR_ID
TOKEN_ENCRYPTION_KEY
```

The dashboard is password protected. `/api/check` additionally requires `Authorization: Bearer <CRON_SECRET>` unless opened by an authenticated dashboard session.

### 4. GitHub Actions

Create a repository variable:

```text
WATCHER_URL=https://YOUR-VERCEL-DOMAIN.vercel.app
```

Create the repository secret:

```text
CRON_SECRET=<same value as Vercel>
```

The five-minute workflow performs a single authenticated HTTP request; it does not reinstall Node dependencies every five minutes.

A monthly keepalive workflow also commits a tiny heartbeat file so scheduled workflows stay active in a public repository.

### 5. Email

Resend is the simplest minimum notification channel. Use a sender address/domain that Resend has verified.

### 6. Google Calendar

Enable Google Calendar API, create an OAuth 2.0 Web Application client, and register exactly:

```text
https://YOUR-VERCEL-DOMAIN/api/google/callback
```

Then open the dashboard and select **Connect Google Calendar**.

The app requests only the Calendar Events scope, stores the refresh token encrypted in Postgres, and refreshes access tokens server-side. On first connection it also synchronizes the currently parsed 2026–27 dates, so connecting Calendar after the schedule has already been released does not leave Calendar empty.

Google OAuth projects left in **Testing** can have short-lived refresh tokens; use the appropriate production/published configuration for a long-running monitor.

### 7. Twilio SMS / WhatsApp

SMS requires a Twilio sender and an E.164 destination.

For proactive WhatsApp alerts, use a Twilio/WhatsApp-approved message template and set `TWILIO_WHATSAPP_CONTENT_SID`.

A useful template is:

```text
EMREE ALERT: {{1}}

{{2}}

Official source: {{3}}
```

## Reliability details

### Fetch reliability

- three attempts for transient failures
- `Retry-After` handling for 429 responses
- request timeout
- conditional `ETag` / `Last-Modified` requests
- response-size guard
- official-content validation before parsing

### False-positive resistance

A page footer edit, analytics parameter, navigation change, or unrelated text update does not create an EMREE release alert. The semantic hash is based on the parsed target-cycle examination rows.

### Duplicate resistance

- database lock prevents concurrent watcher runs
- detection fingerprints include both previous and current semantic state
- notification delivery is unique per detection/channel
- successful channels are never resent just because another channel failed
- a failed channel is retried after 30 minutes
- Google Calendar event IDs are deterministic

### Calendar correctness

A sitting is keyed by its examination date. If NIHS changes registration opening/closing or result date while keeping the same exam sitting, the existing Calendar event is updated rather than deleted and recreated. If a whole sitting disappears, its old Calendar events are removed.

The manual **Sync current dates** button also lists Sentinel-managed events for the current cycle and removes stale ones.

## Local development

```bash
npm install
npm run typecheck
npm test
npm run dev
```

Manual watcher run:

```bash
npm run watch
```

## Suggested production notification setup

Start with **email + Google Calendar**. Add SMS and WhatsApp after those are verified. The core release detector remains independent of the notification providers.

## Optional AI layer

An LLM is intentionally not the release trigger. Deterministic parsing of the official table is safer for a calendar monitor. An optional AI summarizer can be added later to turn a confirmed semantic change into a short human-readable explanation, while leaving the deterministic detector as the source of truth.
