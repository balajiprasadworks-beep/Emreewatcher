# EMREE Watcher

24/7 EMREE 2026–27 official-source watcher.

Architecture: GitHub → Vercel → Neon PostgreSQL → Resend email + optional Telegram.

Recipient is preset to `balajiprasadworks@gmail.com`.

See `.env.example` for production secrets.
